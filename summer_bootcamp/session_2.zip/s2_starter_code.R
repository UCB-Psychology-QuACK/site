# Week 2 - Accessing and Viewing data
# 7/13/2021
# Elena Leib (& Willa in spirit)

#### Warm Up ####

# 1. Create three different vectors: 
## i. A  vector called "names" with three names


## ii. A vector named "ages" with three ages of college students


## iii. A vector called "year" with three years of college (e.g., Freshman, Sophomore, etc.)


# 2. Run the code and check that everything looks correct in the global environment.



#### Set options ####
options(stringsAsFactors = FALSE)


#### Data frames ####




#### Check working directory ####



#### Read in data ####
# Use help function to look up read.csv


# Read in data



#### View data ####
# Check it out in the global environment
## How many columns?


## How many rows?


# View()


# summary()


# str()


#### Make factors ####
# Let's make some columns into factors


# Look at str() and summary() again to check our work, and see what happens


#### stringsAsFactors = FALSE versus stringsAsFactors = TRUE ####