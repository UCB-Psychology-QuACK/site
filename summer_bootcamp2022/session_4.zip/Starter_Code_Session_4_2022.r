# Session 4 - Data visualization with ggplot
# Willa & Elena
# July 27, 2021

# ************************************************************************
#### Set up and load packages #### 
# You will the tidyverse package


options(stringsAsFactors=FALSE)

# ************************************************************************
#### Warm-up  #### 

## 1. Please Sign in! Go to: https://tinyurl.com/r-boot-attend

## 2. Load in penguins dataset and View your data


## 3. Use tidyverse commands to do the following data processing steps (use pipes to connect your commands). 
  # 3a. Remove two columns: "body_mass_g" and "flipper_length_mm".
  
  # 3b. Remove NAs from the dataset
  
  # 3c. Let's say the researchers made a mistake! Those are actually Great penguins, not Gentoo penguins (oh no!). Make a new variable called species2, where those who have a species of Gentoo are fixed and are "Great", and the other types of species stay the same (Adelie is still Adelie and Chinstrap is still Chinstrap).


#### End of Warm-up #### 


# ************************************************************************

#### Data Viz demo ####

#.............................................................................

### Plot 1: Let's look at the distribution of bill_length_mm 

# 1a. Set up our ggplot

# 1b. Add our histogram object 


#.............................................................................

### Plot 2 : Let's compare the body mass of each penguin species using a barplot

# 2a. Set up our ggplot
  
# 2b. Add a column object

  
    #  notice that the species are ordered alphabetically. 
    # We could change this by creating an ordered factor
    # eg. factor(species, levels = c("Chinstrap", "Adelie", "Gentoo"))


## Bar charts aren't the best way to look at data because it doesn't tell us much about individual data points or the distribution of data. 

#.............................................................................

### Plot 3: Let's compare the body mass of each penguin species using some other kinds of plots

# 3a. Let's try a box plot. 

      # i. set up our ggplot
      
      # ii. add a box object 
         

         ## This gives us some more descriptive stats about the data but we still don't
         ## have a good feel for what the distribution of the data points look like.
       

# ............................................................................

# 3b. Lets use a violin plot to visualize the data. 
      # i. Set up our ggplot

      # ii. Add a box object

      # iii. Now let's separate by sex ...

      # iv. Maybe we want a boxplot on top... 
       
       ## A violin plot immediately gives us an idea of the shape of our data. We also
       ## see that while the mean mass of males and females may be similar the
       ## distributions can be quite different.

# ............................................................................

# 3c. Now that we are happy with our plot choice, lets customize it further...

      # v. change axis labels
        
         
      # vi. set title 
         
      
      # vii. change change the y axis scale to start at 25 and end at 65
         
      # viii. change the color scheme. There are a few ways to do this (Only select one and comment out the others!)
         
           # Some color names are built in
            
            
           # We can use color palettes
            
            
      # ix. change the overall theme


# Now let's save our plot!
       
      
       
# ............................................................................

#### Plot 4. Now lets look at the relationship between bill length and bill depth for each species
       
    # i. set up our ggplot
    
    # ii. add a scatter plot
             
    # iii. add a regression line
    
    # iv. split by species

## This gives us an idea of the relationship between these two variables for each species
       
       
       
       
       
       
       
       