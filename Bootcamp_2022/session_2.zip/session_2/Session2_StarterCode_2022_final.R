# Week 2 - R Bootcamp Starter Code
# 7/13/2022

#### Please note that we intend to do this during class today! This is NOT A WARMUP! ####


#### Setting our options #### 
options(stringsAsFActors = FALSE) #older versions of R would automatically make columns with charachters into factors, which is not what we want. So, we're telling R not to make this assumption when it loads in data! 

#### Loading packages #### 
# Load the here, dplyr, and haven packages 


#### Loading in our COVID attitudes data #### 


#### Examining our Data #### 

    # Note: if you add a question mark before a command, R can provide some information about what it does (look in the bottom right corner of your screen! 
    # For instance, what do these do?: 
          ?ncol
          ?nrow
          ?str
          ?summary
    
    # Remember: if you want to call a specific vector (column) from your data frame, use the $ operator! 

    # eg. covid_attitudes$Q74.education

### On your own: 

    ## 1) Use the summary() function to learn about the covid_attitudes dataframe. This should look like: summary(covid_attitudes).  
    ## now use the use the str() function in the same way. What do these do? What do you see? What types of data do we have in our data frame? 


    ## 2) Use the ncol() function. How many columns in our data? 


    ## 3) Use the nrow() function. How many rows in our data? 


    ## 4.1) Some of these columns should be factors! Lets turn the education column into a factor. Use the command factor(covid_attitudes$Q74.education).
    
    ## 4.2) Pick some other column you think should be a factor and turn it into a factor. 


    ## 5) Now use the summary(covid_attitudes$Q74.education) command  to run on summary on just the column with your new factor. 

          ## Does the description change from how it was before? What does it look like now? 


    ## 6) Which columns have the most NAs? Use the summary() command to investigate!


    ## 7) What do you notice about how the NAs are represented in different columns? 
          ## In summary? When you View() it?


    ## 8) On average, how likely do people think they are to catch Covid-19?
          # Hint: you first need to find the relevant column 

    ## 9) How many types of living communities are there?

    
    ## 10) If you have time: Think of another question you can ask with your group and answer it!




