# Session 4 - Data visualization with ggplot
# Willa & Elena
# July 27, 2021

# ************************************************************************
#### Set up and load packages #### 
# You will need both the tidyverse and the psych packages
library(tidyverse)
library(psych)
options(stringsAsFactors=FALSE)

# ************************************************************************
#### Warm-up  #### 

## 1. Please Sign in! Go to: https://tinyurl.com/r-boot-attend

## 2. Load in penguins dataset and View your data
penguins <- read.csv('penguins.csv')

## 3. Use tidyverse commands to do the following data processing steps (use pipes to connect your commands).
    # 3a. Remove two columns: "body_mass_g" and "flipper_length_mm".
    
    # 3b. Remove NAs from the dataset
    
    # 3c. Let's say the researchers made a mistake! Those are actually Great penguins, not Gentoo penguins (oh no!). Make a new variable called species2, where those who have a species of Gentoo are fixed and are "Great", and the other types of species stay the same (Adelie is still Adelie and Chinstrap is still Chinstrap).

penguins_clean <- penguins %>% 
  select(-body_mass_g, -flipper_length_mm) %>% 
  drop_na() %>%
  mutate(species2 = case_when(species == "Gentoo" ~ "Great", 
                              TRUE ~ species))
  # This makes it so that the column species2 will be "Great" for rows where species is "Gentoo". The second line (TRUE ~ species) makes it so that all other rows where species is not missing (e.g., where there is a value), species2 will equal the same value as species for that row 
  #Or, you can do the final step one by one: 
    #mutate(species2 = case_when(species == "Adelie" ~ "Adelie", 
                              #species == "Chinstrap" ~ "Chinstrap",
                              # species == "Gentoo" ~ "Great"))

## 4. Using the describe() function, look at the variable body_length_mm. 
describe(penguins_clean$bill_length_mm)

#### End of Warm-up #### 

# ************************************************************************

#### Data Viz demo ####

# This website has some helpful info about plotting with ggplot: https://datacarpentry.org/R-ecology-lesson/04-visualization-ggplot2.html  

# ggplot cheat sheet: https://www.maths.usyd.edu.au/u/UG/SM/STAT3022/r/current/Misc/data-visualization-2.1.pdf  

# R-graph gallery: Help choosing and creating types of plots (note: only use the ggplot section on each page) https://www.r-graph-gallery.com/index.html  


#.............................................................................

### Plot 1: Let's look at the distribution of bill_length_mm 

# 1a. Set up our ggplot
ggplot(data = penguins_clean, aes(x = bill_length_mm)) + 

# 1b. Add our histogram object 
  geom_histogram() 

  #geom_histogram(color=black) #this outlines the boxes in black


#.............................................................................

### Plot 2 : Let's compare the body mass of each penguin species using a barplot

# 2a. Set up our ggplot
ggplot(data = penguins_clean, aes(x = species, y=bill_length_mm))+
# 2b. Add a column object
 geom_col(position = "dodge")

#  notice that the species are ordered alphabetically. 
# We could change this by creating an ordered factor
# eg. factor(species, levels = c("Chinstrap", "Adelie", "Gentoo"))

 
 ## Bar charts aren't the best way to look at data because it doesn't tell us much about individual data points or the distribution of data. 
 

#.............................................................................

### Plot 3: Let's compare the body mass of each penguin species using some other kinds of plots

# 3a. Let's try a box plot. 

# i. set up our ggplot
ggplot(data = penguins_clean, aes(x = species, y = bill_length_mm)) + 
# ii. add a box object 
geom_boxplot()

## This gives us some more descriptive stats about the data but we still don't
## have a good feel for what the distribution of the data points look like.

 
# ............................................................................

# 3b. Lets use a violin plot to visualize the data. 
# i. Set up our ggplot
ggplot(data = penguins_clean, aes(x = species, y = bill_length_mm, fill=species)) + 
    ## Note that "fill" changes the color of the fill, and "color" changes the 
    ## color of the *outline*
  
# ii. Add a violin object
geom_violin(trim = FALSE) +
  
# iii. Let's say we want separate plots for each sex...
facet_wrap(~sex) +
# iv. Maybe we want a boxplot on top... 
geom_boxplot(width=0.3) 
  
## A violin plot immediately gives us an idea of the shape of our data. We also
## see that while the mean mass of males and females may be similar the
## distributions can be quite different.


# ............................................................................

# 3c. Now that we are happy with our plot choice, lets customize it further...
ggplot(data = penguins_clean, aes(x = species, y = bill_length_mm, color=species)) + 
  geom_violin(trim = FALSE) +
  geom_boxplot(width=0.3) +
  facet_wrap(~sex)+

# v. change axis labels
  labs(x = "Species", y = "Bill Length (mm)")+ 

# vi. set title 

 ggtitle("Bill Length by Species ") +

# vii. change change the y axis scale to start at 25 and end at 65
ylim(25,65) +

# viii. change the color scheme. There are a few ways to do this 
  #(Only select one and comment out the others!)

  ## Some color names are built in
      # scale_fill_manual(values = c("gray", "midnightblue", "dodgerblue1"))+
    
  ## We can give it hex values
      #scale_fill_manual(values=c("#999999", "#E69F00", "#26A2C6"))+

  ## We can use color palettes
       scale_fill_brewer(palette = "Dark2")+

# ix. change the overall theme

  theme_classic()

  
# In case of interest, this website lists a TON of the color names that R has built in: http://www.stat.columbia.edu/~tzheng/files/Rcolor.pdf  

  
# EXTRA -- What happens if we change how we "fill" the aes() in our graph? 

    # Violin plot, no fill 
    ggplot(data = penguins_clean, aes(x = species, y = bill_length_mm)) + 
      geom_violin(trim = FALSE)  
    
    #Violin plot, fill = species 
    ggplot(data = penguins_clean, aes(x = species, y = bill_length_mm, fill=species)) + 
      geom_violin(trim = FALSE)  
    
    #Violin plot, fill = sex 
    ggplot(data = penguins_clean, aes(x = species, y = bill_length_mm, fill=sex))+
      geom_violin(trim = FALSE)
## Why does this happen? 
    ## Remember, aes() stands for aesthetic mapping!
    ## When we tell r to fill by species, and we already have species as the x variable,
    ## we are not asking R to map any additional variables onto our graph. 
    ## So, it sets a different color for each of the species (which was already our x variable).
    ## But, when we set fill=sex, when species is still the x variable, 
    ## we are asking R to map a third variable to its representation of the data. 
    ## Therefore, it splits our species graphs by sex.   
        
  

# *****************************************************************************
#### Plot 4. Now lets look at the relationship between bill length and bill depth for each species

# i. set up our ggplot
ggplot(penguins_clean, aes(y = bill_depth_mm, x=bill_length_mm, color=sex)) + 
  
# ii. add a scatter plot
  geom_point() + 
  
# iii. add a regression line
  geom_smooth(method = "lm") 


## Overall, there appears to be a negative relationship between bill length and bill depth, and this is true for males and females. BUT, could there be something we aren't looking at or capturing? What if we break it up by species...  

# i. set up our ggplot
ggplot(penguins_clean, aes(y = bill_depth_mm, x=bill_length_mm, color=sex)) + 
  
  # ii. add a scatter plot
  geom_point() + 
  
  # iii. add a regression line
  geom_smooth(method = "lm") +
  # iv. split by species
  facet_wrap(~species)
  

## What do we see? For each species, the relationship between bill length and bill depth is positive! It seems that because of differences in bill length/depth across species, this relationship appeared negative when examined at the population level, but positive at the species level. This is why graphing (potentially by group) is so important! 





